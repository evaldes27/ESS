// Tiny JSON-file datastore. No native deps, works anywhere Node runs.
// Fine for our volume (a distributor's order book, not a marketplace).
const fs = require("fs");
const path = require("path");

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
fs.mkdirSync(DATA_DIR, { recursive: true });
const USERS_FILE = path.join(DATA_DIR, "users.json");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");
const TICKETS_FILE = path.join(DATA_DIR, "tickets.json");
const WARRANTIES_FILE = path.join(DATA_DIR, "warranties.json");

function load(file) {
  if (!fs.existsSync(file)) return [];
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return []; }
}
function saveAtomic(file, data) {
  const tmp = file + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file);
}

let users = load(USERS_FILE);
let orders = load(ORDERS_FILE);
let tickets = load(TICKETS_FILE);
let warranties = load(WARRANTIES_FILE);
let nextUserId = users.reduce((m, u) => Math.max(m, u.id), 0) + 1;
let nextOrderId = orders.reduce((m, o) => Math.max(m, o.id), 0) + 1;
let nextTicketId = tickets.reduce((m, t) => Math.max(m, t.id), 0) + 1;
let nextWarrantyId = warranties.reduce((m, w) => Math.max(m, w.id), 0) + 1;

const persistUsers = () => saveAtomic(USERS_FILE, users);
const persistOrders = () => saveAtomic(ORDERS_FILE, orders);
const persistTickets = () => saveAtomic(TICKETS_FILE, tickets);
const persistWarranties = () => saveAtomic(WARRANTIES_FILE, warranties);

module.exports = {
  // ---- users ----
  getUserByEmail(email) { return users.find(u => u.email === email) || null; },
  getUserById(id) { return users.find(u => u.id === id) || null; },
  insertUser(u) {
    const row = { id: nextUserId++, created_at: new Date().toISOString(), ...u };
    users.push(row); persistUsers();
    return row;
  },

  // ---- orders ----
  nextOrderNum() {
    const seq = 1000 + orders.length + 1;
    const rand = Math.random().toString(16).slice(2, 6).toUpperCase();
    return `BSL-${seq}-${rand}`;
  },
  insertOrder(o) {
    const row = { id: nextOrderId++, status: 0, carrier: null, tracking: null, created_at: new Date().toISOString(), ...o };
    orders.push(row); persistOrders();
    return row;
  },
  listOrdersByUser(userId) {
    return orders.filter(o => o.user_id === userId).sort((a, b) => b.id - a.id);
  },
  getOrderByNum(num, userId) {
    return orders.find(o => o.order_num === num && (userId == null || o.user_id === userId)) || null;
  },
  listAllOrders(limit = 200) {
    return orders.slice().sort((a, b) => b.id - a.id).slice(0, limit);
  },
  updateOrderStatus(num, { status, carrier, tracking }) {
    const o = orders.find(x => x.order_num === num);
    if (!o) return null;
    o.status = status; o.carrier = carrier || null; o.tracking = tracking || null;
    persistOrders();
    return o;
  },

  // ---- support tickets ----
  nextTicketNum() {
    const seq = 100 + tickets.length + 1;
    return `TCK-${seq}`;
  },
  insertTicket(t) {
    const row = { id: nextTicketId++, status: "abierto", created_at: new Date().toISOString(), ...t };
    tickets.push(row); persistTickets();
    return row;
  },
  listTicketsByUser(userId) {
    return tickets.filter(t => t.user_id === userId).sort((a, b) => b.id - a.id);
  },
  listAllTickets(limit = 500) {
    return tickets.slice().sort((a, b) => b.id - a.id).slice(0, limit);
  },
  updateTicketStatus(num, status) {
    const tk = tickets.find(x => x.ticket_num === num);
    if (!tk) return null;
    tk.status = status;
    persistTickets();
    return tk;
  },
  categoryCounts() {
    const counts = {};
    for (const t of tickets) counts[t.category] = (counts[t.category] || 0) + 1;
    return counts;
  },

  // ---- warranty registrations ----
  insertWarranty(w) {
    const row = { id: nextWarrantyId++, created_at: new Date().toISOString(), ...w };
    warranties.push(row); persistWarranties();
    return row;
  },
  getWarrantyBySerial(serial) { return warranties.find(w => w.serial === serial) || null; },
  listWarrantiesByUser(userId) {
    return warranties.filter(w => w.user_id === userId).sort((a, b) => b.id - a.id);
  },
  listAllWarranties(limit = 500) {
    return warranties.slice().sort((a, b) => b.id - a.id).slice(0, limit);
  }
};

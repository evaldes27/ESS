// BSL BATT STORE — backend API
// Accounts (register/login), orders tied to accounts, support tickets,
// warranty registration, and admin endpoints. JSON file store, JWT auth.

const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("./db");

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
const ADMIN_KEY = process.env.ADMIN_KEY || "dev-admin-change-me";
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "*").split(",").map(s => s.trim());

const TICKET_CATEGORIES = [
  "instalacion", "garantia_falla", "bms_app_wifi", "envio_logistica", "cotizacion", "otro"
];

const app = express();
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || ALLOWED_ORIGINS.includes("*") || ALLOWED_ORIGINS.includes(origin)) return cb(null, true);
    cb(new Error("Not allowed by CORS"));
  }
}));
app.use(express.json({ limit: "1mb" }));

// ---------- helpers ----------
function signToken(user) {
  return jwt.sign({ uid: user.id, email: user.email }, JWT_SECRET, { expiresIn: "30d" });
}
function authRequired(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: "missing_token" });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.getUserById(payload.uid);
    if (!user) return res.status(401).json({ error: "invalid_token" });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: "invalid_token" });
  }
}
function adminRequired(req, res, next) {
  const key = req.headers["x-admin-key"];
  if (!key || key !== ADMIN_KEY) return res.status(401).json({ error: "unauthorized" });
  next();
}
function publicUser(u) {
  return { id: u.id, name: u.name, company: u.company, email: u.email, phone: u.phone, rfc: u.rfc, cp: u.cp, addr: u.addr, created_at: u.created_at };
}
function formatOrder(row) {
  return {
    num: row.order_num, status: row.status, carrier: row.carrier, tracking: row.tracking,
    items: row.items, usdSub: row.usd_sub, usdIva: row.usd_iva, usdTot: row.usd_tot, mxnTot: row.mxn_tot,
    client: { name: row.ship_name, company: row.ship_company, email: row.ship_email, phone: row.ship_phone, rfc: row.ship_rfc, cp: row.ship_cp, addr: row.ship_addr },
    createdAt: row.created_at
  };
}
function formatTicket(row, userEmail) {
  return {
    num: row.ticket_num, category: row.category, message: row.message, severity: row.severity,
    orderNum: row.order_num || null, status: row.status, createdAt: row.created_at,
    userEmail: userEmail || undefined
  };
}
function formatWarranty(row, userEmail) {
  return {
    serial: row.serial, sku: row.sku, orderNum: row.order_num || null,
    installDate: row.install_date || null, installer: row.installer || null,
    createdAt: row.created_at, userEmail: userEmail || undefined
  };
}

// ---------- health ----------
app.get("/api/health", (req, res) => res.json({ ok: true }));
app.get("/api/support/categories", (req, res) => res.json({ categories: TICKET_CATEGORIES }));

// ---------- auth ----------
app.post("/api/register", (req, res) => {
  const { name, company, email, phone, rfc, cp, addr, password } = req.body || {};
  if (!name || !email || !password) return res.status(400).json({ error: "missing_fields" });
  if (String(password).length < 6) return res.status(400).json({ error: "weak_password" });
  const emailNorm = String(email).trim().toLowerCase();
  if (db.getUserByEmail(emailNorm)) return res.status(409).json({ error: "email_taken" });
  const password_hash = bcrypt.hashSync(password, 10);
  const user = db.insertUser({
    name, company: company || null, email: emailNorm, phone: phone || null,
    rfc: rfc || null, cp: cp || null, addr: addr || null, password_hash
  });
  res.json({ token: signToken(user), user: publicUser(user) });
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "missing_fields" });
  const emailNorm = String(email).trim().toLowerCase();
  const user = db.getUserByEmail(emailNorm);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: "invalid_credentials" });
  }
  res.json({ token: signToken(user), user: publicUser(user) });
});

app.get("/api/me", authRequired, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

// ---------- orders (customer) ----------
app.post("/api/orders", authRequired, (req, res) => {
  const b = req.body || {};
  const items = Array.isArray(b.items) ? b.items : [];
  if (items.length === 0) return res.status(400).json({ error: "empty_order" });
  const order = db.insertOrder({
    order_num: db.nextOrderNum(), user_id: req.user.id, items,
    usd_sub: b.usdSub || 0, usd_iva: b.usdIva || 0, usd_tot: b.usdTot || 0, mxn_tot: b.mxnTot || 0,
    ship_name: b.name || req.user.name, ship_company: b.company || req.user.company,
    ship_email: b.email || req.user.email, ship_phone: b.phone || req.user.phone,
    ship_rfc: b.rfc || req.user.rfc, ship_cp: b.cp || req.user.cp, ship_addr: b.addr || req.user.addr
  });
  res.json({ order: formatOrder(order) });
});

app.get("/api/orders", authRequired, (req, res) => {
  res.json({ orders: db.listOrdersByUser(req.user.id).map(formatOrder) });
});

app.get("/api/orders/:num", authRequired, (req, res) => {
  const row = db.getOrderByNum(req.params.num, req.user.id);
  if (!row) return res.status(404).json({ error: "not_found" });
  res.json({ order: formatOrder(row) });
});

// ---------- support tickets (customer) ----------
app.post("/api/support", authRequired, (req, res) => {
  const { category, message, orderNum, severity } = req.body || {};
  if (!category || !TICKET_CATEGORIES.includes(category)) return res.status(400).json({ error: "bad_category" });
  if (!message || String(message).trim().length < 5) return res.status(400).json({ error: "message_too_short" });
  const ticket = db.insertTicket({
    ticket_num: db.nextTicketNum(), user_id: req.user.id, category,
    message: String(message).trim(), order_num: orderNum || null,
    severity: ["baja", "media", "urgente"].includes(severity) ? severity : "media"
  });
  res.json({ ticket: formatTicket(ticket) });
});

app.get("/api/support", authRequired, (req, res) => {
  res.json({ tickets: db.listTicketsByUser(req.user.id).map(t => formatTicket(t)) });
});

// ---------- warranty registration (customer) ----------
app.post("/api/warranty", authRequired, (req, res) => {
  const { serial, sku, orderNum, installDate, installer } = req.body || {};
  if (!serial || !sku) return res.status(400).json({ error: "missing_fields" });
  if (db.getWarrantyBySerial(serial)) return res.status(409).json({ error: "serial_already_registered" });
  const w = db.insertWarranty({
    serial: String(serial).trim(), sku, order_num: orderNum || null, user_id: req.user.id,
    install_date: installDate || null, installer: installer || null
  });
  res.json({ warranty: formatWarranty(w) });
});

app.get("/api/warranty", authRequired, (req, res) => {
  res.json({ warranties: db.listWarrantiesByUser(req.user.id).map(w => formatWarranty(w)) });
});

// ---------- admin (Alejandra / Emmanuel) ----------
app.get("/api/admin/orders", adminRequired, (req, res) => {
  const rows = db.listAllOrders().map(r => {
    const u = db.getUserById(r.user_id);
    return { ...formatOrder(r), userEmail: u ? u.email : null };
  });
  res.json({ orders: rows });
});

app.post("/api/admin/orders/:num/status", adminRequired, (req, res) => {
  const { status, carrier, tracking } = req.body || {};
  if (![0, 1, 2, 3].includes(status)) return res.status(400).json({ error: "bad_status" });
  const row = db.updateOrderStatus(req.params.num, { status, carrier, tracking });
  if (!row) return res.status(404).json({ error: "not_found" });
  res.json({ order: formatOrder(row) });
});

app.get("/api/admin/support", adminRequired, (req, res) => {
  const rows = db.listAllTickets().map(t => {
    const u = db.getUserById(t.user_id);
    return formatTicket(t, u ? u.email : null);
  });
  res.json({ tickets: rows, categoryCounts: db.categoryCounts() });
});

app.post("/api/admin/support/:num/status", adminRequired, (req, res) => {
  const { status } = req.body || {};
  if (!["abierto", "en_proceso", "resuelto"].includes(status)) return res.status(400).json({ error: "bad_status" });
  const row = db.updateTicketStatus(req.params.num, status);
  if (!row) return res.status(404).json({ error: "not_found" });
  res.json({ ticket: formatTicket(row) });
});

app.get("/api/admin/warranty", adminRequired, (req, res) => {
  const rows = db.listAllWarranties().map(w => {
    const u = db.getUserById(w.user_id);
    return formatWarranty(w, u ? u.email : null);
  });
  res.json({ warranties: rows });
});

app.listen(PORT, () => console.log(`BSL BATT STORE API listening on :${PORT}`));
